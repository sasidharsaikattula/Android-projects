export interface Task {
  id: string;
  title: string;
  description: string;
  dueDate: string;
  completed: boolean;
  createdAt: string;
  updatedAt: string;
}

export type TaskFilter = 'all' | 'pending' | 'completed';

export type CreateTaskData = Omit<Task, 'id' | 'createdAt' | 'updatedAt'>;
export type UpdateTaskData = Partial<Omit<Task, 'id' | 'createdAt' | 'updatedAt'>>;