import { useState, useEffect, useCallback } from 'react';
import { Task, CreateTaskData, UpdateTaskData, TaskFilter } from '@/types/Task';
import { TaskStorage } from '@/services/TaskStorage';

export function useTasks() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadTasks = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const loadedTasks = await TaskStorage.getAllTasks();
      setTasks(loadedTasks);
    } catch (err) {
      setError('Failed to load tasks');
      console.error('Error loading tasks:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  const createTask = useCallback(async (taskData: CreateTaskData) => {
    try {
      setError(null);
      const newTask = await TaskStorage.createTask(taskData);
      setTasks(prevTasks => [newTask, ...prevTasks]);
      return newTask;
    } catch (err) {
      setError('Failed to create task');
      console.error('Error creating task:', err);
      throw err;
    }
  }, []);

  const updateTask = useCallback(async (id: string, updates: UpdateTaskData) => {
    try {
      setError(null);
      const updatedTask = await TaskStorage.updateTask(id, updates);
      if (updatedTask) {
        setTasks(prevTasks => 
          prevTasks.map(task => task.id === id ? updatedTask : task)
        );
      }
      return updatedTask;
    } catch (err) {
      setError('Failed to update task');
      console.error('Error updating task:', err);
      throw err;
    }
  }, []);

  const deleteTask = useCallback(async (id: string) => {
    try {
      setError(null);
      const success = await TaskStorage.deleteTask(id);
      if (success) {
        setTasks(prevTasks => prevTasks.filter(task => task.id !== id));
      }
      return success;
    } catch (err) {
      setError('Failed to delete task');
      console.error('Error deleting task:', err);
      throw err;
    }
  }, []);

  const toggleTask = useCallback(async (id: string) => {
    try {
      setError(null);
      const updatedTask = await TaskStorage.toggleTaskCompletion(id);
      if (updatedTask) {
        setTasks(prevTasks => 
          prevTasks.map(task => task.id === id ? updatedTask : task)
        );
      }
      return updatedTask;
    } catch (err) {
      setError('Failed to toggle task');
      console.error('Error toggling task:', err);
      throw err;
    }
  }, []);

  const getFilteredTasks = useCallback((filter: TaskFilter) => {
    switch (filter) {
      case 'completed':
        return tasks.filter(task => task.completed);
      case 'pending':
        return tasks.filter(task => !task.completed);
      default:
        return tasks;
    }
  }, [tasks]);

  useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  return {
    tasks,
    loading,
    error,
    createTask,
    updateTask,
    deleteTask,
    toggleTask,
    getFilteredTasks,
    refreshTasks: loadTasks,
  };
}