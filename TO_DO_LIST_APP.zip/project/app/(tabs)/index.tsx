import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  RefreshControl,
  StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Plus, Search } from 'lucide-react-native';
import { useFonts, Inter_400Regular, Inter_600SemiBold } from '@expo-google-fonts/inter';
import { Task, TaskFilter, CreateTaskData, UpdateTaskData } from '@/types/Task';
import { useTasks } from '@/hooks/useTasks';
import { useTheme } from '@/hooks/useTheme';
import { Colors } from '@/constants/Colors';
import { TaskItem } from '@/components/TaskItem';
import { TaskForm } from '@/components/TaskForm';
import { FilterTabs } from '@/components/FilterTabs';
import { EmptyState } from '@/components/EmptyState';

export default function TasksScreen() {
  const { isDark } = useTheme();
  const colors = isDark ? Colors.dark : Colors.light;
  
  const [fontsLoaded] = useFonts({
    'Inter-Regular': Inter_400Regular,
    'Inter-SemiBold': Inter_600SemiBold,
  });

  const {
    tasks,
    loading,
    error,
    createTask,
    updateTask,
    deleteTask,
    toggleTask,
    getFilteredTasks,
    refreshTasks,
  } = useTasks();

  const [activeFilter, setActiveFilter] = useState<TaskFilter>('all');
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  const filteredTasks = useMemo(() => 
    getFilteredTasks(activeFilter), 
    [getFilteredTasks, activeFilter]
  );

  const taskCounts = useMemo(() => ({
    all: tasks.length,
    pending: tasks.filter(t => !t.completed).length,
    completed: tasks.filter(t => t.completed).length,
  }), [tasks]);

  const handleCreateTask = async (taskData: CreateTaskData) => {
    await createTask(taskData);
  };

  const handleUpdateTask = async (taskData: CreateTaskData) => {
    if (editingTask) {
      const updates: UpdateTaskData = {
        title: taskData.title,
        description: taskData.description,
        dueDate: taskData.dueDate,
      };
      await updateTask(editingTask.id, updates);
      setEditingTask(null);
    }
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setShowTaskForm(true);
  };

  const handleCloseForm = () => {
    setShowTaskForm(false);
    setEditingTask(null);
  };

  const handleSaveTask = async (taskData: CreateTaskData) => {
    if (editingTask) {
      await handleUpdateTask(taskData);
    } else {
      await handleCreateTask(taskData);
    }
  };

  if (!fontsLoaded) {
    return null;
  }

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    header: {
      paddingHorizontal: 16,
      paddingVertical: 20,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    headerTop: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 16,
    },
    title: {
      fontSize: 32,
      fontWeight: '700',
      color: colors.text,
      fontFamily: 'Inter-SemiBold',
    },
    searchButton: {
      padding: 8,
      borderRadius: 8,
      backgroundColor: colors.surface,
    },
    subtitle: {
      fontSize: 16,
      color: colors.textSecondary,
      fontFamily: 'Inter-Regular',
    },
    content: {
      flex: 1,
    },
    list: {
      flex: 1,
    },
    listContent: {
      paddingBottom: 100,
    },
    fab: {
      position: 'absolute',
      bottom: 20,
      right: 20,
      width: 56,
      height: 56,
      borderRadius: 28,
      backgroundColor: colors.primary,
      alignItems: 'center',
      justifyContent: 'center',
      shadowColor: colors.shadow,
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.3,
      shadowRadius: 12,
      elevation: 8,
    },
    errorContainer: {
      padding: 16,
      backgroundColor: colors.error + '20',
      marginHorizontal: 16,
      marginTop: 16,
      borderRadius: 8,
    },
    errorText: {
      color: colors.error,
      textAlign: 'center',
      fontFamily: 'Inter-Regular',
    },
  });

  const getSubtitle = () => {
    if (loading) return 'Loading tasks...';
    if (error) return 'Error loading tasks';
    
    const { all, pending, completed } = taskCounts;
    if (all === 0) return 'No tasks yet';
    
    return `${pending} pending, ${completed} completed`;
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar
        barStyle={isDark ? 'light-content' : 'dark-content'}
        backgroundColor={colors.background}
      />
      
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <Text style={styles.title}>My Tasks</Text>
          <TouchableOpacity style={styles.searchButton}>
            <Search size={20} color={colors.textSecondary} />
          </TouchableOpacity>
        </View>
        <Text style={styles.subtitle}>{getSubtitle()}</Text>
      </View>

      {error && (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}

      <View style={styles.content}>
        <FilterTabs
          activeFilter={activeFilter}
          onFilterChange={setActiveFilter}
          taskCounts={taskCounts}
        />

        {filteredTasks.length === 0 ? (
          <EmptyState filter={activeFilter} />
        ) : (
          <FlatList
            style={styles.list}
            contentContainerStyle={styles.listContent}
            data={filteredTasks}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <TaskItem
                task={item}
                onToggle={toggleTask}
                onEdit={handleEditTask}
                onDelete={deleteTask}
              />
            )}
            refreshControl={
              <RefreshControl
                refreshing={loading}
                onRefresh={refreshTasks}
                tintColor={colors.primary}
                colors={[colors.primary]}
              />
            }
            showsVerticalScrollIndicator={false}
          />
        )}
      </View>

      <TouchableOpacity
        style={styles.fab}
        onPress={() => setShowTaskForm(true)}
        activeOpacity={0.8}
      >
        <Plus size={24} color={colors.background} strokeWidth={2.5} />
      </TouchableOpacity>

      <TaskForm
        visible={showTaskForm}
        task={editingTask}
        onClose={handleCloseForm}
        onSave={handleSaveTask}
      />
    </SafeAreaView>
  );
}