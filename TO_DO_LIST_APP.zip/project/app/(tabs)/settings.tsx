import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  Moon,
  Sun,
  Smartphone,
  Trash2,
  Info,
  Download,
  Upload,
} from 'lucide-react-native';
import { useFonts, Inter_400Regular, Inter_600SemiBold } from '@expo-google-fonts/inter';
import { useTheme, ThemeMode } from '@/hooks/useTheme';
import { useTasks } from '@/hooks/useTasks';
import { Colors } from '@/constants/Colors';

export default function SettingsScreen() {
  const { isDark, themeMode, setTheme } = useTheme();
  const { tasks } = useTasks();
  const colors = isDark ? Colors.dark : Colors.light;
  
  const [fontsLoaded] = useFonts({
    'Inter-Regular': Inter_400Regular,
    'Inter-SemiBold': Inter_600SemiBold,
  });

  const handleClearAllTasks = () => {
    Alert.alert(
      'Clear All Tasks',
      `This will permanently delete all ${tasks.length} tasks. This action cannot be undone.`,
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Delete All',
          style: 'destructive',
          onPress: async () => {
            // Clear all tasks by deleting them one by one
            // In a real app, you might want a more efficient bulk delete
            for (const task of tasks) {
              // This would need to be implemented in the tasks hook
              // await deleteTask(task.id);
            }
          },
        },
      ]
    );
  };

  const handleExportTasks = () => {
    Alert.alert(
      'Export Tasks',
      'Export functionality would save your tasks to a file or cloud service.',
      [{ text: 'OK' }]
    );
  };

  const handleImportTasks = () => {
    Alert.alert(
      'Import Tasks',
      'Import functionality would load tasks from a file or cloud service.',
      [{ text: 'OK' }]
    );
  };

  const handleAbout = () => {
    Alert.alert(
      'About To-Do App',
      'A beautiful and intuitive task management app built with React Native and Expo.\n\nVersion 1.0.0',
      [{ text: 'OK' }]
    );
  };

  if (!fontsLoaded) {
    return null;
  }

  const themeOptions: { value: ThemeMode; label: string; icon: React.ReactNode }[] = [
    {
      value: 'light',
      label: 'Light',
      icon: <Sun size={20} color={colors.textSecondary} />,
    },
    {
      value: 'dark',
      label: 'Dark',
      icon: <Moon size={20} color={colors.textSecondary} />,
    },
    {
      value: 'system',
      label: 'System',
      icon: <Smartphone size={20} color={colors.textSecondary} />,
    },
  ];

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    header: {
      paddingHorizontal: 16,
      paddingVertical: 20,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    title: {
      fontSize: 32,
      fontWeight: '700',
      color: colors.text,
      fontFamily: 'Inter-SemiBold',
    },
    subtitle: {
      fontSize: 16,
      color: colors.textSecondary,
      marginTop: 4,
      fontFamily: 'Inter-Regular',
    },
    content: {
      flex: 1,
    },
    section: {
      paddingHorizontal: 16,
      paddingVertical: 20,
    },
    sectionTitle: {
      fontSize: 18,
      fontWeight: '600',
      color: colors.text,
      marginBottom: 16,
      fontFamily: 'Inter-SemiBold',
    },
    settingItem: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 16,
      paddingHorizontal: 16,
      backgroundColor: colors.card,
      borderRadius: 12,
      marginBottom: 8,
    },
    settingIcon: {
      marginRight: 12,
    },
    settingContent: {
      flex: 1,
    },
    settingTitle: {
      fontSize: 16,
      fontWeight: '500',
      color: colors.text,
      fontFamily: 'Inter-Regular',
    },
    settingDescription: {
      fontSize: 14,
      color: colors.textSecondary,
      marginTop: 2,
      fontFamily: 'Inter-Regular',
    },
    themeOptions: {
      flexDirection: 'row',
      marginTop: 12,
      gap: 8,
    },
    themeOption: {
      flex: 1,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      paddingVertical: 12,
      paddingHorizontal: 16,
      borderRadius: 8,
      borderWidth: 1,
      borderColor: colors.border,
      backgroundColor: colors.surface,
    },
    activeThemeOption: {
      borderColor: colors.primary,
      backgroundColor: colors.primaryLight,
    },
    themeOptionText: {
      fontSize: 14,
      fontWeight: '500',
      color: colors.textSecondary,
      marginLeft: 8,
      fontFamily: 'Inter-Regular',
    },
    activeThemeOptionText: {
      color: colors.primary,
    },
    separator: {
      height: 1,
      backgroundColor: colors.border,
      marginHorizontal: 16,
    },
    statsContainer: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginTop: 8,
    },
    statItem: {
      alignItems: 'center',
    },
    statValue: {
      fontSize: 20,
      fontWeight: '600',
      color: colors.primary,
      fontFamily: 'Inter-SemiBold',
    },
    statLabel: {
      fontSize: 12,
      color: colors.textTertiary,
      marginTop: 2,
      fontFamily: 'Inter-Regular',
    },
    dangerItem: {
      backgroundColor: colors.error + '20',
    },
    dangerIcon: {
      color: colors.error,
    },
    dangerText: {
      color: colors.error,
    },
  });

  const completedTasks = tasks.filter(t => t.completed).length;
  const pendingTasks = tasks.filter(t => !t.completed).length;

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar
        barStyle={isDark ? 'light-content' : 'dark-content'}
        backgroundColor={colors.background}
      />
      
      <View style={styles.header}>
        <Text style={styles.title}>Settings</Text>
        <Text style={styles.subtitle}>Customize your experience</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Appearance</Text>
          
          <View style={styles.settingItem}>
            <Moon size={20} color={colors.textSecondary} style={styles.settingIcon} />
            <View style={styles.settingContent}>
              <Text style={styles.settingTitle}>Theme</Text>
              <Text style={styles.settingDescription}>
                Choose your preferred color scheme
              </Text>
              <View style={styles.themeOptions}>
                {themeOptions.map((option) => (
                  <TouchableOpacity
                    key={option.value}
                    style={[
                      styles.themeOption,
                      themeMode === option.value && styles.activeThemeOption,
                    ]}
                    onPress={() => setTheme(option.value)}
                  >
                    {option.icon}
                    <Text
                      style={[
                        styles.themeOptionText,
                        themeMode === option.value && styles.activeThemeOptionText,
                      ]}
                    >
                      {option.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </View>
        </View>

        <View style={styles.separator} />

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Data</Text>
          
          <TouchableOpacity style={styles.settingItem} onPress={handleExportTasks}>
            <Upload size={20} color={colors.textSecondary} style={styles.settingIcon} />
            <View style={styles.settingContent}>
              <Text style={styles.settingTitle}>Export Tasks</Text>
              <Text style={styles.settingDescription}>
                Save your tasks to a file
              </Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity style={styles.settingItem} onPress={handleImportTasks}>
            <Download size={20} color={colors.textSecondary} style={styles.settingIcon} />
            <View style={styles.settingContent}>
              <Text style={styles.settingTitle}>Import Tasks</Text>
              <Text style={styles.settingDescription}>
                Load tasks from a file
              </Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity 
            style={[styles.settingItem, styles.dangerItem]} 
            onPress={handleClearAllTasks}
          >
            <Trash2 size={20} color={colors.error} style={styles.settingIcon} />
            <View style={styles.settingContent}>
              <Text style={[styles.settingTitle, styles.dangerText]}>
                Clear All Tasks
              </Text>
              <Text style={styles.settingDescription}>
                Permanently delete all tasks
              </Text>
            </View>
          </TouchableOpacity>
        </View>

        <View style={styles.separator} />

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Statistics</Text>
          
          <View style={styles.settingItem}>
            <View style={styles.settingContent}>
              <Text style={styles.settingTitle}>Task Overview</Text>
              <Text style={styles.settingDescription}>
                Your productivity at a glance
              </Text>
              <View style={styles.statsContainer}>
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>{tasks.length}</Text>
                  <Text style={styles.statLabel}>Total</Text>
                </View>
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>{pendingTasks}</Text>
                  <Text style={styles.statLabel}>Pending</Text>
                </View>
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>{completedTasks}</Text>
                  <Text style={styles.statLabel}>Completed</Text>
                </View>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.separator} />

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About</Text>
          
          <TouchableOpacity style={styles.settingItem} onPress={handleAbout}>
            <Info size={20} color={colors.textSecondary} style={styles.settingIcon} />
            <View style={styles.settingContent}>
              <Text style={styles.settingTitle}>About</Text>
              <Text style={styles.settingDescription}>
                Version and app information
              </Text>
            </View>
          </TouchableOpacity>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}