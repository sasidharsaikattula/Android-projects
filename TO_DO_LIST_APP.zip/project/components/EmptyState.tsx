import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { CircleCheck as CheckCircle, ListTodo, Clock } from 'lucide-react-native';
import { TaskFilter } from '@/types/Task';
import { useTheme } from '@/hooks/useTheme';
import { Colors } from '@/constants/Colors';

interface EmptyStateProps {
  filter: TaskFilter;
}

export function EmptyState({ filter }: EmptyStateProps) {
  const { isDark } = useTheme();
  const colors = isDark ? Colors.dark : Colors.light;

  const getEmptyStateContent = () => {
    switch (filter) {
      case 'completed':
        return {
          icon: <CheckCircle size={64} color={colors.textTertiary} />,
          title: 'No completed tasks',
          subtitle: 'Complete some tasks to see them here',
        };
      case 'pending':
        return {
          icon: <Clock size={64} color={colors.textTertiary} />,
          title: 'No pending tasks',
          subtitle: 'Great! You\'ve completed all your tasks',
        };
      default:
        return {
          icon: <ListTodo size={64} color={colors.textTertiary} />,
          title: 'No tasks yet',
          subtitle: 'Tap the + button to add your first task',
        };
    }
  };

  const content = getEmptyStateContent();

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      paddingHorizontal: 32,
      paddingVertical: 64,
    },
    icon: {
      marginBottom: 16,
    },
    title: {
      fontSize: 20,
      fontWeight: '600',
      color: colors.text,
      textAlign: 'center',
      marginBottom: 8,
    },
    subtitle: {
      fontSize: 16,
      color: colors.textSecondary,
      textAlign: 'center',
      lineHeight: 24,
    },
  });

  return (
    <View style={styles.container}>
      <View style={styles.icon}>
        {content.icon}
      </View>
      <Text style={styles.title}>{content.title}</Text>
      <Text style={styles.subtitle}>{content.subtitle}</Text>
    </View>
  );
}